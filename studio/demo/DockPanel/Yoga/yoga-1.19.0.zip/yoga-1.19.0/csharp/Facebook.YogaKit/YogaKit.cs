﻿using System.Collections.Generic;
using Facebook.Yoga;

namespace Facebook.YogaKit
{
	public static partial class YogaKit
	{
		internal static Dictionary<YogaNode, object> Bridges = new Dictionary<YogaNode, object>();
	}
}
