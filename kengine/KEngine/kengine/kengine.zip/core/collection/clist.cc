#include "clist.h"

CList::CList()
{
}

CList::~CList()
{
}

void CList::add(void* e)
{
}

void CList::remove(void* index)
{
}

CNode CList::find(int index)
{
	return CNode();
}

bool CList::isEmpty()
{
	return false;
}

int CList::size()
{
	return 0;
}
