#pragma once
enum DebugInfoType
{
	LOG,
	MEMORY,
};

class DebugInfo
{
	DebugInfoType type;
	
};
class Monitor
{
public:
	void log();
	void track_memory();
};