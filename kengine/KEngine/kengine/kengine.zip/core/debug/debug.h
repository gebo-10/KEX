//
// Created by jiajun.qiu on 2021/9/28.
//

#pragma once

#ifdef DEBUG_ENABLED

inline void * __cdecl operator new(unsigned int size, const char *file, int line)
{
    void *ptr = std::malloc(size);
    //AddTrack((DWORD)ptr, size, file, line);
    return(ptr);
};

inline void __cdecl operator delete(void *p)
{
    //RemoveTrack((DWORD)p);
    std::free(p);
};
#define new new(__FILE__, __LINE__)

inline void *  melloc(unsigned int size, const char *file, int line)
{
    void *ptr = std::malloc(size);
    //AddTrack((DWORD)ptr, size, file, line);
    return(ptr);
};

inline void operator free(void *p)
{
    //RemoveTrack((DWORD)p);
    std::free(p);
};
#endif