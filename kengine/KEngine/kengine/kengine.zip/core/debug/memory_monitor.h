#pragma once
#include <functional>
#include<unordered_map>
#include<hash_map>
#define MAX_POOL 10240
struct MemeryInfo{
    int line;
    char file[64];
};
struct AllocItem{
    MemeryInfo * memery_info;
    int size;
    int64 adress;
};
class MemoryMonitor{
    static MemeryInfo[MAX_POOL] memory_item_pool;
    static AllocItem[MAX_POOL] alloc_item_pool;
    std::hash_map<string, MemeryInfo*> memory_info;
    std::hash_map<void *, AllocItem*> alloc_info;
    MemoryMonitor(){
        for(int i=0; i< MEMORY_POOL_SIZE; i++) {
            auto new_item = std::melloc(sizeof(MemeryInfo));
            memory_item_pool.add(new_item);
        }
    }
    void OnAlloc(void* address, int size, string file, int line ){
        std::melloc(MemeryInfo)
        std::hash<std::string> h;
    }

    void OnFree(int64 address){

    }
};