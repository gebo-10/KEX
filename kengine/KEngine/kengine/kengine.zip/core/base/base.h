#pragma  once
#include "type.h"
#include "log.h"
#include "buffer.h"
#include "color.h"
#include "memory.h"