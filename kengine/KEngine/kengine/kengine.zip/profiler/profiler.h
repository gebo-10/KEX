#pragma once
#include <uv.h>
#include <chrono>
#include "../core/base/base.h"

namespace kengine {
	class Profiler
	{
	public:
		Profiler(){}
		~Profiler() {}
		void init(int fps_limit_) {
		
		}
		
	private:

	};

}
