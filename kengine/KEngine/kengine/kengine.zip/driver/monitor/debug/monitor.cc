#include "..\..\..\core\debug\monitor.h"

void Monitor::log()
{
}

void Monitor::track_memory()
{
}
