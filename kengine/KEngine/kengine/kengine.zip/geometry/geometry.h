#pragma once
#include "plane.h"
namespace kengine {
	class Geometry
	{
	public:
		Geometry()
		{
		}

		~Geometry()
		{
		}

		
	};

}