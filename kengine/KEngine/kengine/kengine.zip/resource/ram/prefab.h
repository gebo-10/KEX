#pragma once
#include "resource.h"
namespace kengine {
	class Prefabs :public Resource
	{
	public:
		Prefabs()
		{
		}

		~Prefabs()
		{
		}

	private:

	};

}
