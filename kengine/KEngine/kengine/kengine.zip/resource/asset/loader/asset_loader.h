#pragma once
namespace kengine
{
	class AssetLoader
	{
	public:
		AssetLoader()
		{
		}

		~AssetLoader()
		{
		}

		virtual bool load()
		{
		}

		virtual void load_async()
		{
		}
	};
}

