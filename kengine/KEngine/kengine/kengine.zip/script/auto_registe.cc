#include "auto_registe.h"
namespace kengine {
void reg_all(sol::table& lua){
	reg_kengine(lua);
}
}
