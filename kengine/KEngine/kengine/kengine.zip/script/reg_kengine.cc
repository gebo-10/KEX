#include "auto_registe.h"
#include <kengine/kengine.h>
namespace kengine {
void reg_kengine(sol::table& lua) {
	
}
}
