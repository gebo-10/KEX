#pragma once
#include<sol.hpp>
namespace kengine {
extern void reg_all(sol::table& lua);
extern void reg_kengine(sol::table& lua);
}
