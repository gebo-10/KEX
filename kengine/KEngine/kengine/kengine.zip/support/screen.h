#pragma once
namespace kengine {
	class Screen
	{
	public:
		static int width;
		static int height;

		Screen()
		{
		}

		~Screen()
		{
		}

	private:

	};

}