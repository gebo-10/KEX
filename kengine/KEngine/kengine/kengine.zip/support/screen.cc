#include "screen.h"
namespace kengine {
	int Screen::width;
	int Screen::height;
}
