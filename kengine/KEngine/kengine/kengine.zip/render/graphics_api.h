#pragma once
#define OPENGL

#ifdef GLES3
#include <GLES3/gl3.h>
#endif

#ifdef OPENGL
#include <GL/glew.h>
#endif