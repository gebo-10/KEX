#pragma once
#include"bind_point_manager.h"
namespace kengine {
	class Graphics
	{
	public:
		BindPointManager bind_point_manager;
	};
}
