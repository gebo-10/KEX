#pragma once
#include <kengine/core/math/kmath.h>
#include <kengine/scene/scene.h>
namespace kengine {

	//#pragma pack(4)
	struct CommonUniform { //alignas
	public:
		vec4 time;
		CameraData camears[8];
		LightData lights[16];
		//vec4	light_dir;
		//Color	light_color;
		//Matrix v;
		//Matrix p;
		//Matrix pv;

		GPUBufferPtr uniform_buffer = nullptr;
		void sync() {
			if (uniform_buffer == nullptr) {
				uniform_buffer = std::make_shared<GPUBuffer>(sizeof(CommonUniform) - sizeof(GPUBufferPtr), GPUBufferType::UNIFORM_BUFFER, GPUBufferHit::DYNAMIC_DRAW);
				uniform_buffer->bind_to_point(0);
				uniform_buffer->map(GPUBufferHit::WRITE_ONLY);
			}
			memcpy(uniform_buffer->map_data, this, sizeof(CommonUniform) - sizeof(GPUBufferPtr));
		}
	};
	//#pragma pack()
}
